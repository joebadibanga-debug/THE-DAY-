# THE DAY BUSINESS RDC — génération APK sans installer Flutter

Ce projet est préparé pour être compilé à distance avec GitHub Actions.

## Ce que cela évite

Il n'est pas nécessaire d'installer Flutter, Android Studio ou le SDK Android sur l'ordinateur local.

## Étapes

1. Créer un dépôt GitHub vide, par exemple `THE_DAY_BUSINESS_RDC`.
2. Envoyer tout le contenu de ce dossier dans le dépôt.
3. Ouvrir l'onglet **Actions** du dépôt.
4. Lancer **Build THE DAY BUSINESS RDC APK** avec **Run workflow**.
5. Une fois le travail terminé, ouvrir l'exécution réussie et télécharger l'artefact **THE_DAY_BUSINESS_RDC_APK**.
6. L'archive téléchargée contient `app-release.apk`, installable sur Android.

Le workflow installe automatiquement Flutter et les outils nécessaires sur le serveur GitHub.
